import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class OrderHolder {
    public class Holder {
        Button increase;
        Button decrease;
        TextView orderquantity;
        ImageView itemimage;
        TextView itemname;
        TextView rate;
    }
}