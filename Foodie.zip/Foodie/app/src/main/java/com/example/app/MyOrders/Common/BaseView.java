package com.example.app.MyOrders.Common;

public interface BaseView {
    void showDialog();

    void hideDialog();

    void showError(String message);
}
