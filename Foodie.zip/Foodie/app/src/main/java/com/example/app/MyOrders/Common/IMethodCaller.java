package com.example.app.MyOrders.Common;

public interface IMethodCaller {
    void yourDesiredMethod(String text);
}
